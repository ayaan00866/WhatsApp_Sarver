package com.ayan.ghosttype

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.inputmethodservice.InputMethodService
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.*
import android.content.Intent
import android.provider.Settings
import kotlin.math.roundToInt

class GhostTypeImeService : InputMethodService() {
    companion object {
        const val ACTION_OPEN_AUTO_PANEL = "com.ayan.ghosttype.OPEN_AUTO_PANEL"
        const val ACTION_START_AUTO_TYPE = "com.ayan.ghosttype.START_AUTO_TYPE"
        const val ACTION_PAUSE_AUTO_TYPE = "com.ayan.ghosttype.PAUSE_AUTO_TYPE"
        const val ACTION_STOP_AUTO_TYPE = "com.ayan.ghosttype.STOP_AUTO_TYPE"
        const val ACTION_RESET_AUTO_TYPE = "com.ayan.ghosttype.RESET_AUTO_TYPE"
        private const val MAX_SEND_RETRIES = 2
        private const val SEND_RETRY_DELAY_MS = 700L
    }

    private val brandBackground = Color.rgb(232, 237, 242)
    private val brandSurface = Color.rgb(255, 255, 255)
    private val brandRaised = Color.rgb(204, 211, 220)
    private val brandBorder = Color.rgb(214, 220, 227)
    private val brandText = Color.rgb(24, 27, 34)
    private val brandMuted = Color.rgb(102, 108, 118)
    private val brandGold = Color.rgb(42, 121, 226)
    private val brandIce = Color.rgb(42, 121, 226)
    private val brandRed = Color.rgb(214, 67, 72)

    private val handler = Handler(Looper.getMainLooper())
    private var input: InputConnection? = null
    private var keyboard: KeyboardSurface? = null
    private var panel: LinearLayout? = null
    private var autoText: EditText? = null
    private var autoStatus: TextView? = null
    private var editorInfo: EditorInfo? = null
    private var running = false
    private var paused = false
    private var lineIndex = 0
    private var charIndex = 0
    private var lines = emptyList<String>()
    private var autoState = AutoTypeState.IDLE
    private var taskSignature = ""
    private var sendAttempts = 0
    private var capsLock = false
    private var mathMode = false
    private var emojiMode = false
    private val autoStep = object : Runnable {
        override fun run() {
            advanceAutoType()
        }
    }
    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_OPEN_AUTO_PANEL -> openAutoPanel()
                ACTION_START_AUTO_TYPE -> startAutoType()
                ACTION_PAUSE_AUTO_TYPE -> {
                    if (autoState == AutoTypeState.RUNNING) pauseAutoType() else resumeAutoType()
                }
                ACTION_STOP_AUTO_TYPE -> stopAutoType()
                ACTION_RESET_AUTO_TYPE -> resetAutoProgress()
            }
        }
    }

    override fun onCreateInputView(): View {
        input = currentInputConnection
        return makeKeyboard()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreate() {
        super.onCreate()
        window.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.window?.setDimAmount(0f)
        val filter = android.content.IntentFilter().apply {
            addAction(ACTION_OPEN_AUTO_PANEL)
            addAction(ACTION_START_AUTO_TYPE)
            addAction(ACTION_PAUSE_AUTO_TYPE)
            addAction(ACTION_STOP_AUTO_TYPE)
            addAction(ACTION_RESET_AUTO_TYPE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(commandReceiver) }
        super.onDestroy()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        input = currentInputConnection
        editorInfo = info
    }

    override fun onFinishInput() {
        stopAutoType()
        super.onFinishInput()
    }

    private fun makeKeyboard(): View {
        keyboard = KeyboardSurface()
        val bottomGap = dp(8)
        val host = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            clipChildren = false
            addView(
                keyboard,
                FrameLayout.LayoutParams(-1, keyboardHeightPx(), android.view.Gravity.BOTTOM).apply {
                    bottomMargin = bottomGap
                },
            )
        }
        return host
    }

    private fun keyboardHost(content: View): View = FrameLayout(this).apply {
        setBackgroundColor(Color.TRANSPARENT)
        clipChildren = false
        addView(content, FrameLayout.LayoutParams(-1, keyboardHeightPx(), android.view.Gravity.BOTTOM).apply {
            bottomMargin = dp(8)
        })
    }

    private fun imeButton(
        label: String,
        backgroundColor: Int = brandRaised,
        foregroundColor: Int = brandText,
        action: () -> Unit,
    ) = Button(this).apply {
        text = label
        textSize = 11f
        setTextColor(foregroundColor)
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        gravity = android.view.Gravity.CENTER
        setPadding(dp(4), 0, dp(4), 0)
        background = rounded(backgroundColor, 12, brandBorder)
        elevation = dp(2).toFloat()
        setOnClickListener { action() }
    }

    private fun openToolsPanel() {
        val background = brandBackground
        val ink = brandText
        val accent = brandGold
        val muted = brandMuted
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(background)
        }
        val header = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "TOOLS"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
        }, LinearLayout.LayoutParams(0, dp(34), 1f))
        header.addView(TextView(this).apply {
            text = "Quick keyboard controls"
            textSize = 10f
            setTextColor(muted)
            gravity = android.view.Gravity.CENTER_VERTICAL
        })
        root.addView(header, LinearLayout.LayoutParams(-1, dp(34)))

        val tools = listOf(
            "↻\nFYT" to { openFytPanel() },
            "⇧\nCaps" to {
                capsLock = !capsLock
                setInputView(makeKeyboard())
            },
            "▣\nClipboard" to { openClipboardPanel() },
            "▶\nAuto-Type" to { openAutoPanel() },
            "☺\nEmoji" to { openEmojiMode() },
            "⌨\nKeyboard" to {
                mathMode = false
                emojiMode = false
                setInputView(makeKeyboard())
            },
            "⚙\nSettings" to { openKeyboardSettings() },
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tools.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
            rowItems.forEach { (label, action) ->
                row.addView(
                    imeButton(label, brandRaised, ink, action),
                    LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                        setMargins(dp(2), dp(2), dp(2), dp(2))
                    },
                )
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, dp(54)))
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(imeButton("▣  Back to keyboard", brandSurface, ink) {
            setInputView(makeKeyboard())
        }, LinearLayout.LayoutParams(-1, dp(36)))
        setInputView(keyboardHost(root))
    }

    private fun openMathMode() {
        mathMode = true
        emojiMode = false
        setInputView(makeKeyboard())
    }

    private fun openEmojiMode() {
        emojiMode = true
        mathMode = false
        setInputView(makeKeyboard())
    }

    private fun openFytPanel() {
        val background = brandBackground
        val ink = brandText
        val accent = brandGold
        val surface = brandRaised
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(background)
        }
        root.addView(TextView(this).apply {
            text = "FYT MODE"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
        }, LinearLayout.LayoutParams(-1, dp(30)))
        root.addView(TextView(this).apply {
            text = "Repeat each typed character by the count you choose."
            textSize = 11f
            setTextColor(brandMuted)
        }, LinearLayout.LayoutParams(-1, dp(30)))
        val toggle = Switch(this).apply {
            text = "FYT mode"
            textSize = 13f
            setTextColor(ink)
            isChecked = Prefs.fytEnabled(this@GhostTypeImeService)
            setOnCheckedChangeListener { _, value -> Prefs.setFytEnabled(this@GhostTypeImeService, value) }
        }
        root.addView(toggle, LinearLayout.LayoutParams(-1, dp(42)))
        val count = TextView(this).apply {
            text = Prefs.fytCount(this@GhostTypeImeService).toString()
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = android.view.Gravity.CENTER
            setTextColor(accent)
        }
        val countRow = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER }
        countRow.addView(imeButton("−", surface, ink) {
            Prefs.setFytCount(this@GhostTypeImeService, Prefs.fytCount(this@GhostTypeImeService) - 1)
            count.text = Prefs.fytCount(this@GhostTypeImeService).toString()
        }, LinearLayout.LayoutParams(dp(48), dp(40)))
        countRow.addView(count, LinearLayout.LayoutParams(dp(90), dp(40)))
        countRow.addView(imeButton("+", surface, ink) {
            Prefs.setFytCount(this@GhostTypeImeService, Prefs.fytCount(this@GhostTypeImeService) + 1)
            count.text = Prefs.fytCount(this@GhostTypeImeService).toString()
        }, LinearLayout.LayoutParams(dp(48), dp(40)))
        root.addView(countRow, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(Space(this), LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(imeButton("▣  Back to keyboard", surface, ink) {
            setInputView(makeKeyboard())
        }, LinearLayout.LayoutParams(-1, dp(36)))
        setInputView(keyboardHost(root))
    }

    private fun openClipboardPanel() {
        rememberCurrentClipboard()
        val background = brandBackground
        val ink = brandText
        val accent = brandGold
        val surface = brandRaised
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(background)
        }
        root.addView(TextView(this).apply {
            text = "CLIPBOARD"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
        }, LinearLayout.LayoutParams(-1, dp(30)))
        root.addView(TextView(this).apply {
            text = "Saved clips are inserted at the current cursor."
            textSize = 11f
            setTextColor(brandMuted)
        }, LinearLayout.LayoutParams(-1, dp(28)))
        val history = Prefs.clipboardHistory(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        history.take(4).forEach { clip ->
            val preview = clip.replace("\n", " ").take(42)
            list.addView(imeButton("▣  $preview", surface, ink) {
                input?.commitText(clip, 1)
                setInputView(makeKeyboard())
            }, LinearLayout.LayoutParams(-1, dp(36)).apply { setMargins(0, dp(2), 0, dp(2)) })
        }
        if (history.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No saved clips yet. Copy text, then open Clipboard again."
                textSize = 11f
                setTextColor(brandMuted)
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(imeButton("↻  Refresh saved clips", surface, ink) {
            openClipboardPanel()
        }, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(imeButton("▣  Back to keyboard", surface, ink) {
            setInputView(makeKeyboard())
        }, LinearLayout.LayoutParams(-1, dp(34)).apply { setMargins(0, dp(4), 0, 0) })
        setInputView(keyboardHost(root))
    }

    private fun rememberCurrentClipboard() {
        runCatching {
            val manager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = manager.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (clip.isNotBlank()) Prefs.rememberClipboard(this, clip)
        }
    }

    private fun cycleKeyboardFont() {
        val fonts = listOf("System", "Sans Serif", "Monospace")
        val current = fonts.indexOf(Prefs.font(this)).coerceAtLeast(0)
        val next = fonts[(current + 1) % fonts.size]
        Prefs.setFont(this, next)
        Toast.makeText(this, "Font: $next", Toast.LENGTH_SHORT).show()
        setInputView(makeKeyboard())
    }

    private fun openKeyboardSettings() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_OPEN_PAGE, "keyboard")
        })
    }

    private fun keyboardHeightPx(): Int {
        val screenHeight = resources.displayMetrics.heightPixels
        val fraction = (0.34f * Prefs.keyHeight(this) / 100f).coerceIn(0.28f, 0.42f)
        return (screenHeight * fraction).roundToInt()
    }

    private fun openAutoPanel() {
        val panelBackground = brandBackground
        val panelInk = brandText
        val panelAccent = brandGold
        val panelSurface = brandRaised
        val panelMuted = brandMuted
        val panelBorder = brandBorder
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(panelBackground)
        }
        fun compactLp(height: Int, top: Int = 0, bottom: Int = 0) =
            LinearLayout.LayoutParams(-1, dp(height)).apply {
                setMargins(0, dp(top), 0, dp(bottom))
            }
        fun panelButton(
            label: String,
            backgroundColor: Int,
            foregroundColor: Int,
            action: (Button) -> Unit,
        ) = Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(foregroundColor)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            gravity = android.view.Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            background = rounded(backgroundColor, 28, panelBorder)
            setOnClickListener { action(this) }
        }
        val header = LinearLayout(this).apply {
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Auto-Type"
            textSize = 18f
            setTextColor(panelAccent)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -1, 1f))
        val state = panelButton("■  STOPPED", panelSurface, panelInk) {
            if (running) {
                stopAutoType()
            } else {
                startAutoType()
            }
        }.apply {
            tag = "state"
            textSize = 11f
        }
        header.addView(state, LinearLayout.LayoutParams(dp(126), dp(34)))
        root.addView(header, compactLp(36, bottom = 6))
        root.addView(TextView(this).apply {
            text = "MESSAGE QUEUE"
            textSize = 14f
            setTextColor(panelMuted)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }, compactLp(22, top = 2, bottom = 5))
        autoText = EditText(this).apply {
            hint = "One message per line"
            setText(Prefs.messages(this@GhostTypeImeService))
            textSize = 13f
            setTextColor(panelInk)
            setHintTextColor(panelMuted)
            background = rounded(panelSurface, 12, panelBorder)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setGravity(android.view.Gravity.TOP)
            minLines = 2
            maxLines = 3
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(autoText, compactLp(48, bottom = 5))
        syncProgressForText(autoText?.text?.toString().orEmpty())
        val status = TextView(this).apply {
            text = progressLabel()
            textSize = 10f
            setTextColor(panelMuted)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        autoStatus = status
        root.addView(status, compactLp(18, bottom = 5))
        val delay = TextView(this).apply {
            text = "Delay ${Prefs.messageDelay(this@GhostTypeImeService)}s"
            setTextColor(panelInk)
            textSize = 12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
        }
        val minus = panelButton("−", panelSurface, panelInk) {
            Prefs.setMessageDelay(this@GhostTypeImeService, Prefs.messageDelay(this@GhostTypeImeService) - 1)
            delay.text = "Delay ${Prefs.messageDelay(this@GhostTypeImeService)}s"
        }
        val plus = panelButton("+", panelSurface, panelInk) {
            Prefs.setMessageDelay(this@GhostTypeImeService, Prefs.messageDelay(this@GhostTypeImeService) + 1)
            delay.text = "Delay ${Prefs.messageDelay(this@GhostTypeImeService)}s"
        }
        val delayRow = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
        delayRow.addView(minus, LinearLayout.LayoutParams(dp(38), dp(34)).apply {
            setMargins(0, 0, dp(6), 0)
        })
        delayRow.addView(delay, LinearLayout.LayoutParams(dp(82), dp(34)).apply {
            setMargins(0, 0, dp(4), 0)
        })
        delayRow.addView(plus, LinearLayout.LayoutParams(dp(38), dp(34)).apply {
            setMargins(dp(2), 0, dp(10), 0)
        })
        val loop = panelButton(if (Prefs.loop(this)) "↻  Loop ON" else "↻  Loop OFF", panelSurface, panelInk) {
            Prefs.setLoop(this, !Prefs.loop(this))
            it.text = if (Prefs.loop(this)) "↻  Loop ON" else "↻  Loop OFF"
        }
        delayRow.addView(loop, LinearLayout.LayoutParams(0, dp(34), 1f).apply {
            setMargins(dp(2), 0, 0, 0)
        })
        root.addView(delayRow, compactLp(38, top = 2, bottom = 8))
        val actions = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER }
        val start = panelButton("▶  START", panelAccent, brandBackground) {
            if (running) {
                stopAutoType()
            } else {
                startAutoType()
            }
        }.apply { tag = "start" }
        val pause = panelButton("Ⅱ  Pause", panelSurface, panelAccent) {
            if (autoState == AutoTypeState.RUNNING) pauseAutoType()
            else if (autoState == AutoTypeState.PAUSED || autoState == AutoTypeState.STOPPED) resumeAutoType()
            status.text = progressLabel()
            it.text = if (autoState == AutoTypeState.RUNNING) "Ⅱ  Pause" else "Ⅱ  Resume"
        }
        pause.tag = "pause"
        actions.addView(start, LinearLayout.LayoutParams(0, dp(44), 1.35f).apply {
            setMargins(0, 0, dp(10), 0)
        })
        actions.addView(pause, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(actions, compactLp(48, bottom = 8))
        root.addView(panelButton("▣  Back to keyboard", panelSurface, panelInk) {
            setInputView(makeKeyboard())
        }, compactLp(42))
        panel = root
        val bottomGap = dp(8)
        val host = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            clipChildren = false
            addView(root, FrameLayout.LayoutParams(-1, keyboardHeightPx(), android.view.Gravity.BOTTOM).apply {
                bottomMargin = bottomGap
            })
        }
        setInputView(host)
    }

    private fun startAutoType() {
        val text = autoText?.text?.toString().orEmpty()
        lines = parseLines(text).map(::withTargetPrefix)
        if (lines.isEmpty()) {
            autoStatus?.text = "Add at least one line first"
            return
        }
        Prefs.setMessages(this, text)
        syncProgressForText(text)
        if (autoState == AutoTypeState.COMPLETED && !Prefs.loop(this)) {
            autoStatus?.text = "Completed • reset progress to run again"
            return
        }
        running = true
        paused = false
        autoState = AutoTypeState.RUNNING
        sendAttempts = 0
        persistCursor()
        updateAutoControls()
        scheduleNext(0L)
    }

    private fun scheduleNext(delayMs: Long = Prefs.charDelay(this).toLong()) {
        if (autoState != AutoTypeState.RUNNING) return
        handler.removeCallbacks(autoStep)
        handler.postDelayed(autoStep, delayMs.coerceAtLeast(0L))
    }

    private fun advanceAutoType() {
        if (autoState != AutoTypeState.RUNNING) return
        if (lineIndex >= lines.size) {
            if (Prefs.loop(this)) {
                lineIndex = 0
                charIndex = 0
                sendAttempts = 0
                persistCursor()
                scheduleNext(Prefs.messageDelay(this).toLong() * 1000L)
            } else {
                running = false
                paused = false
                autoState = AutoTypeState.COMPLETED
                persistCursor()
                updateAutoControls()
            }
            return
        }

        val current = lines[lineIndex]
        if (charIndex < current.length) {
            val ch = current[charIndex].toString()
            input?.commitText(ch, 1)
            charIndex += 1
            persistCursor()
            keyboard?.activeKey = ch
            autoStatus?.text = progressLabel()
            keyboard?.invalidate()
            scheduleNext()
            return
        }

        if (Prefs.autoSend(this)) {
            val sent = when (Prefs.sendMethod(this)) {
                "access" -> GhostTypeAccessibilityService.clickVisibleSendButton()
                "enter" -> sendLine()
                else -> GhostTypeAccessibilityService.clickVisibleSendButton() || sendLine()
            }
            if (!sent) {
                sendAttempts += 1
                autoStatus?.text = if (sendAttempts < MAX_SEND_RETRIES) {
                    "Send button not detected • retrying $sendAttempts/$MAX_SEND_RETRIES"
                } else {
                    "Send failed • stopped safely; press Resume to retry"
                }
                if (sendAttempts < MAX_SEND_RETRIES) {
                    scheduleNext(SEND_RETRY_DELAY_MS)
                } else {
                    running = false
                    paused = false
                    autoState = AutoTypeState.STOPPED
                    persistCursor()
                    updateAutoControls()
                }
                return
            }
        }

        sendAttempts = 0
        lineIndex += 1
        charIndex = 0
        persistCursor()
        autoStatus?.text = progressLabel()
        scheduleNext(Prefs.messageDelay(this).toLong() * 1000L)
    }

    private fun sendLine(): Boolean {
        val connection = input ?: currentInputConnection ?: return false
        val action = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        when (action) {
            EditorInfo.IME_ACTION_NONE,
            EditorInfo.IME_ACTION_UNSPECIFIED,
            null -> {
                connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                return true
            }
            else -> {
                if (connection.performEditorAction(action)) return true
            }
        }
        connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        return true
    }

    private fun pauseAutoType() {
        if (autoState != AutoTypeState.RUNNING) return
        running = false
        paused = true
        autoState = AutoTypeState.PAUSED
        handler.removeCallbacks(autoStep)
        persistCursor()
        updateAutoControls()
    }

    private fun resumeAutoType() {
        if (lines.isEmpty()) {
            lines = parseLines(Prefs.messages(this)).map(::withTargetPrefix)
        }
        if (lines.isEmpty()) {
            autoStatus?.text = "Add at least one line first"
            return
        }
        running = true
        paused = false
        autoState = AutoTypeState.RUNNING
        persistCursor()
        updateAutoControls()
        scheduleNext(0L)
    }

    private fun stopAutoType() {
        running = false
        paused = false
        handler.removeCallbacks(autoStep)
        if (autoState != AutoTypeState.COMPLETED) autoState = AutoTypeState.STOPPED
        persistCursor()
        keyboard?.activeKey = null
        updateAutoControls()
        keyboard?.invalidate()
    }

    private fun resetAutoProgress() {
        running = false
        paused = false
        handler.removeCallbacks(autoStep)
        lineIndex = 0
        charIndex = 0
        sendAttempts = 0
        taskSignature = ""
        autoState = AutoTypeState.IDLE
        Prefs.resetAutoProgress(this)
        updateAutoControls()
        keyboard?.activeKey = null
        keyboard?.invalidate()
    }

    private fun syncProgressForText(text: String) {
        lines = parseLines(text).map(::withTargetPrefix)
        val signature = taskSignature(text)
        if (signature != Prefs.autoTaskSignature(this)) {
            lineIndex = 0
            charIndex = 0
            autoState = AutoTypeState.IDLE
            taskSignature = signature
            Prefs.setAutoTaskSignature(this, signature)
            Prefs.setAutoLineIndex(this, 0)
            Prefs.setAutoCharIndex(this, 0)
            Prefs.setAutoState(this, AutoTypeState.IDLE)
        } else {
            lineIndex = Prefs.autoLineIndex(this).coerceIn(0, lines.size)
            charIndex = Prefs.autoCharIndex(this).coerceAtLeast(0)
            autoState = Prefs.autoState(this)
            taskSignature = signature
            if (autoState == AutoTypeState.RUNNING) {
                autoState = AutoTypeState.STOPPED
                Prefs.setAutoState(this, autoState)
            }
        }
        if (lineIndex < lines.size) {
            charIndex = charIndex.coerceAtMost(lines[lineIndex].length)
        } else {
            charIndex = 0
        }
        updateAutoControls()
    }

    private fun persistCursor() {
        Prefs.setAutoLineIndex(this, lineIndex)
        Prefs.setAutoCharIndex(this, charIndex)
        Prefs.setAutoState(this, autoState)
        Prefs.setAutoTaskSignature(this, taskSignature)
        autoStatus?.text = progressLabel()
    }

    private fun updateAutoControls() {
        val startButton = panel?.findViewWithTag<Button>("start")
        startButton?.text = if (running) "■  STOP" else "▶  START"
        startButton?.background = rounded(
            if (running) brandRed else brandGold,
            28,
            brandBorder,
        )
        val stateButton = panel?.findViewWithTag<Button>("state")
        stateButton?.text = when {
            running -> "■  RUNNING"
            autoState == AutoTypeState.PAUSED -> "Ⅱ  PAUSED"
            autoState == AutoTypeState.COMPLETED -> "✓  COMPLETE"
            else -> "■  STOPPED"
        }
        stateButton?.background = rounded(
            if (running) brandRed else brandSurface,
            28,
            brandBorder,
        )
        panel?.findViewWithTag<Button>("pause")?.let {
            it.text = if (running) "Ⅱ  Pause" else "Ⅱ  Resume"
        }
        autoStatus?.text = progressLabel()
    }

    private fun progressLabel(): String {
        val total = lines.size
        val shownLine = if (total == 0) 0 else (lineIndex + 1).coerceAtMost(total)
        val stateLabel = when (autoState) {
            AutoTypeState.RUNNING -> "Running"
            AutoTypeState.PAUSED -> "Paused"
            AutoTypeState.COMPLETED -> "Completed"
            AutoTypeState.STOPPED -> "Stopped"
            AutoTypeState.IDLE -> "Ready"
        }
        val target = Prefs.target(this).ifBlank { "no prefix" }
        return "$stateLabel • Line $shownLine / $total • Prefix $target"
    }

    private fun parseLines(text: String) =
        text.split("\n").map { it.trimEnd('\r') }.filter { it.isNotEmpty() }

    private fun taskSignature(text: String): String =
        "${text.hashCode()}:${text.length}:${Prefs.target(this)}"

    private fun withTargetPrefix(message: String): String {
        val target = Prefs.target(this).trim()
        return if (target.isBlank()) message else "$target $message"
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int?): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            stroke?.let { setStroke(dp(1), it) }
        }

    private fun button(label: String, click: (View) -> Unit) = Button(this).apply {
        text = label; tag = if (label == "START") "start" else null; setTextColor(Color.WHITE); setOnClickListener(click)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height).apply { setMargins(0, dp(4), 0, dp(4)) }
    private fun weightLp(width: Float, weight: Float) = LinearLayout.LayoutParams(if (weight > 0) 0 else width.toInt(), dp(44), weight)

    private inner class KeyboardSurface : View(this@GhostTypeImeService) {
        private val keyboardBackground = Color.rgb(232, 237, 242)
        private val keyboardKey = Color.rgb(255, 255, 255)
        private val keyboardSpecial = Color.rgb(204, 211, 220)
        private val keyboardInk = Color.rgb(24, 27, 34)
        private val keyboardMuted = Color.rgb(102, 108, 118)
        private val keyboardBorder = Color.rgb(214, 220, 227)
        private val keyboardBlue = Color.rgb(42, 121, 226)
        private val keyboardActive = Color.rgb(218, 231, 250)
        private val toolbarEmojis = listOf("👍", "😌", "😄", "😂", "💋", "🥺", "🫂", "❤️", "😁")
        var activeKey: String? = null
        private var shift = capsLock
        private var symbols = false
        private val keys = listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("Q","W","E","R","T","Y","U","I","O","P"),
            listOf("A","S","D","F","G","H","J","K","L"),
            listOf("⇧","Z","X","C","V","B","N","M","⌫"),
        )
        private val emojiPages = listOf(
            listOf("😀","😂","😍","🔥","👍","🙏","🎉","❤️","✅","✨"),
            listOf("😎","🤔","😅","😭","🥳","🤝","👏","💯","🚀","🌟"),
            listOf("🍎","🍕","☕","🎵","⚽","🚗","✈️","🌈","☀️","🌙"),
        )
        private val mathRows = listOf(
            listOf("π","√","²","³","÷","×","−","±","="),
            listOf("(",")","%","^","<",">","≤","≥","∞"),
            listOf("sin","cos","tan","log","ln",".","⌫"),
        )
        init {
            setBackgroundColor(keyboardBackground)
            isFocusable = true
        }
        override fun onDraw(c: android.graphics.Canvas) {
            super.onDraw(c)
            val bottomGap = keyboardBottomGap()
            val contentHeight = (height - bottomGap).coerceAtLeast(dp(180))
            val backgroundPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = keyboardBackground
            }
            c.drawRect(0f, 0f, width.toFloat(), contentHeight.toFloat(), backgroundPaint)
            backgroundPaint.color = keyboardBackground
            c.drawRect(0f, contentHeight.toFloat(), width.toFloat(), height.toFloat(), backgroundPaint)
            val visible = visibleRows()
            val toolbarH = toolbarHeight(contentHeight)
            val contentRows = visible.size + if (Prefs.numberRow(this@GhostTypeImeService)) 1 else 0
            val totalRows = contentRows + 1
            val rowH = rowHeight(contentHeight, totalRows, toolbarH)
            drawToolbar(c, toolbarH)
            var rowTop = toolbarH
            if (Prefs.numberRow(this@GhostTypeImeService)) {
                drawRow(c, keys[0], rowTop, 10, rowH)
                rowTop += rowH
            }
            visible.forEach { values ->
                drawRow(c, values, rowTop, values.size, rowH)
                rowTop += rowH
            }
            drawBottom(c, rowTop, rowH)
        }

        private fun visibleRows(): List<List<String>> = when {
            emojiMode -> emojiPages
            mathMode -> mathRows
            symbols -> listOf(
                listOf("@", "#", "$", "%", "&", "*", "(", ")", "/", "?"),
                listOf("-", "+", "=", "_", ";", ":", "'", "\"", "⌫"),
            )
            else -> keys.drop(1)
        }

        private fun toolbarHeight(contentHeight: Int): Float =
            (contentHeight * 0.25f).coerceIn(dp(102).toFloat(), dp(150).toFloat())

        private fun rowHeight(contentHeight: Int, rowCount: Int, toolbarHeight: Float): Float =
            (contentHeight - toolbarHeight) / rowCount.coerceAtLeast(1)
        private fun drawRow(c: android.graphics.Canvas, values: List<String>, y: Float, count: Int, rowH: Float) {
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            paint.textAlign = android.graphics.Paint.Align.CENTER
            paint.typeface = keyboardTypeface()
            val keyW = width / count.toFloat()
            values.forEachIndexed { index, label ->
                val left = index * keyW + dp(8)
                val rect = android.graphics.RectF(left, y + dp(7), (index + 1) * keyW - dp(8), y + rowH - dp(7))
                val active = activeKey != null && label.equals(activeKey, ignoreCase = true)
                val special = label == "⇧" || label == "⌫"
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = Color.argb(34, 35, 40, 50)
                c.drawRoundRect(
                    rect.left,
                    rect.top + dp(2),
                    rect.right,
                    rect.bottom + dp(2),
                    dp(8).toFloat(),
                    dp(8).toFloat(),
                    paint,
                )
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = when {
                    active -> keyboardActive
                    special -> keyboardSpecial
                    else -> keyboardKey
                }
                c.drawRoundRect(rect, dp(8).toFloat(), dp(8).toFloat(), paint)
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = dp(1).toFloat()
                paint.color = if (active) keyboardBlue else keyboardBorder
                c.drawRoundRect(rect, dp(8).toFloat(), dp(8).toFloat(), paint)
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = keyboardInk
                paint.textSize = if (label.length > 1) dp(18).toFloat() else dp(20).toFloat()
                c.drawText(if (!symbols && !mathMode && !emojiMode && label.length == 1 && !shift && !capsLock) label.lowercase() else label, rect.centerX(), rect.centerY() - (paint.ascent() + paint.descent()) / 2, paint)
            }
        }

        private fun drawToolbar(c: android.graphics.Canvas, h: Float) {
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            paint.color = keyboardBackground
            c.drawRect(0f, 0f, width.toFloat(), h, paint)

            val gridLeft = dp(16).toFloat()
            val gridTop = dp(12).toFloat()
            paint.color = keyboardMuted
            repeat(4) { index ->
                val x = gridLeft + (index % 2) * dp(13)
                val y = gridTop + (index / 2) * dp(13)
                c.drawRoundRect(
                    x, y, x + dp(9), y + dp(9),
                    dp(2).toFloat(), dp(2).toFloat(), paint
                )
            }

            if (running) {
                paint.color = keyboardBlue
                paint.textSize = dp(11).toFloat()
                paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
                paint.textAlign = android.graphics.Paint.Align.CENTER
                c.drawText(
                    "TYPING  •  ${lineIndex + 1}/${lines.size.coerceAtLeast(1)}",
                    width / 2f,
                    dp(28).toFloat(),
                    paint,
                )
            }

            paint.color = keyboardInk
            paint.textSize = dp(22).toFloat()
            paint.typeface = keyboardTypeface()
            paint.textAlign = android.graphics.Paint.Align.CENTER
            val emojiY = h - dp(25).toFloat()
            toolbarEmojis.forEachIndexed { index, emoji ->
                val x = width * ((index + 0.65f) / (toolbarEmojis.size + 0.35f))
                c.drawText(emoji, x, emojiY - (paint.ascent() + paint.descent()) / 2, paint)
            }
        }

        private fun drawBottom(c: android.graphics.Canvas, y: Float, h: Float) {
            val labels = if (Prefs.emojiKey(this@GhostTypeImeService)) listOf("?123", ",", "☺", "space", ".", "↵") else listOf("?123", ",", "space", ".", "↵")
            val weights = if (Prefs.emojiKey(this@GhostTypeImeService)) {
                listOf(1.25f, 0.8f, 0.9f, 3.0f, 0.8f, 1.35f)
            } else {
                listOf(1.25f, 0.8f, 3.0f, 0.8f, 1.35f)
            }
            drawWeightedRow(c, labels, weights, y, h)
        }

        private fun drawWeightedRow(c: android.graphics.Canvas, values: List<String>, weights: List<Float>, y: Float, rowH: Float) {
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            paint.textAlign = android.graphics.Paint.Align.CENTER
            paint.typeface = keyboardTypeface()
            val total = weights.sum()
            var cursor = 0f
            values.forEachIndexed { index, label ->
                val keyW = width * (weights[index] / total)
                val rect = android.graphics.RectF(cursor + dp(9), y + dp(7), cursor + keyW - dp(9), y + rowH - dp(7))
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = Color.argb(34, 35, 40, 50)
                c.drawRoundRect(
                    rect.left,
                    rect.top + dp(2),
                    rect.right,
                    rect.bottom + dp(2),
                    dp(11).toFloat(),
                    dp(11).toFloat(),
                    paint,
                )
                paint.color = when {
                    label == "↵" -> keyboardBlue
                    label == "?123" -> keyboardSpecial
                    else -> keyboardKey
                }
                paint.style = android.graphics.Paint.Style.FILL
                c.drawRoundRect(rect, dp(11).toFloat(), dp(11).toFloat(), paint)
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = dp(1).toFloat()
                paint.color = if (label == "↵") keyboardBlue else keyboardBorder
                c.drawRoundRect(rect, dp(11).toFloat(), dp(11).toFloat(), paint)
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = if (label == "↵") Color.WHITE else keyboardInk
                paint.textSize = if (label == "space") dp(12).toFloat() else dp(16).toFloat()
                c.drawText(label, rect.centerX(), rect.centerY() - (paint.ascent() + paint.descent()) / 2, paint)
                cursor += keyW
            }
        }

        private fun bottomLabelAt(x: Float): String {
            val labels = if (Prefs.emojiKey(this@GhostTypeImeService)) listOf("?123", ",", "☺", "space", ".", "↵") else listOf("?123", ",", "space", ".", "↵")
            val weights = if (Prefs.emojiKey(this@GhostTypeImeService)) listOf(1.25f, 0.8f, 0.9f, 3.0f, 0.8f, 1.35f) else listOf(1.25f, 0.8f, 3.0f, 0.8f, 1.35f)
            val total = weights.sum()
            var cursor = 0f
            labels.forEachIndexed { index, label ->
                val end = cursor + width * (weights[index] / total)
                if (x < end) return label
                cursor = end
            }
            return labels.last()
        }
        private var pressedLabel: String? = null
        private var didRepeat = false
        private val repeatRunnable = object : Runnable {
            override fun run() {
                val label = pressedLabel ?: return
                if (!isRepeatable(label)) return
                didRepeat = true
                handleKey(label)
                handler.postDelayed(this, 70L)
            }
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    val label = if (isToolbarTap(event.x, event.y)) null else labelAt(event.x, event.y)
                    pressedLabel = label
                    activeKey = label
                    didRepeat = false
                    invalidate()
                    if (label != null && isRepeatable(label)) {
                        handler.postDelayed(repeatRunnable, 360L)
                    }
                    return true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(repeatRunnable)
                    val label = pressedLabel
                    pressedLabel = null
                    activeKey = null
                    invalidate()
                    if (isToolbarTap(event.x, event.y)) {
                        openToolsPanel()
                        return true
                    }
                    if (label != null && !didRepeat) handleKey(label)
                    return true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeatRunnable)
                    pressedLabel = null
                    activeKey = null
                    invalidate()
                    return true
                }
            }
            return true
        }

        private fun labelAt(x: Float, y: Float): String? {
            val bottomGap = keyboardBottomGap()
            val contentHeight = (height - bottomGap).coerceAtLeast(dp(180))
            if (y > contentHeight) return null
            val visible = visibleRows()
            val toolbarH = toolbarHeight(contentHeight)
            if (y < toolbarH) return toolbarEmojiAt(x, y, toolbarH)
            val rowCount = visible.size + if (Prefs.numberRow(this@GhostTypeImeService)) 1 else 0
            val rowH = rowHeight(contentHeight, rowCount + 1, toolbarH)
            val row = ((y - toolbarH) / rowH).toInt()
            if (row == rowCount) return bottomLabelAt(x)
            val number = Prefs.numberRow(this@GhostTypeImeService)
            val values = if (number && row == 0) {
                keys[0]
            } else {
                visible.getOrNull(row - if (number) 1 else 0) ?: return null
            }
            return values[(x / (width / values.size.toFloat())).toInt().coerceIn(0, values.lastIndex)]
        }

        private fun isToolbarTap(x: Float, y: Float): Boolean {
            val bottomGap = keyboardBottomGap()
            val contentHeight = (height - bottomGap).coerceAtLeast(dp(180))
            if (y < 0f || y > contentHeight) return false
            val toolbarH = toolbarHeight(contentHeight)
            return y < toolbarH * 0.55f && x < dp(72)
        }

        private fun toolbarEmojiAt(x: Float, y: Float, toolbarH: Float): String? {
            if (y < toolbarH * 0.45f || x < dp(36) || x > width - dp(20)) return null
            val left = dp(36).toFloat()
            val right = (width - dp(20)).toFloat()
            val slot = (right - left) / toolbarEmojis.size
            val index = ((x - left) / slot).toInt().coerceIn(0, toolbarEmojis.lastIndex)
            return toolbarEmojis[index]
        }

        private fun keyboardBottomGap(): Int =
            maxOf(dp(10), (height * 0.08f).toInt())

        private fun isRepeatable(label: String): Boolean =
            label != "⇧" && label != "?123" && label != "↵"

        private fun handleKey(label: String) {
            when (label) {
                "?123" -> { symbols = !symbols; emojiMode = false; mathMode = false; invalidate() }
                "☺" -> {
                    emojiMode = !emojiMode
                    if (emojiMode) {
                        mathMode = false
                        symbols = false
                    }
                    invalidate()
                }
                "space" -> commit(" ")
                "," -> commit(",")
                "." -> commit(".")
                "↵" -> sendLine()
                "⇧" -> { shift = !shift; invalidate() }
                "⌫" -> input?.deleteSurroundingText(1, 0)
                else -> if (emojiMode || mathMode) commit(label) else commit(if (shift || capsLock) label else label.lowercase())
            }
        }
        private fun commit(value: String) {
            val repeats = if (Prefs.fytEnabled(this@GhostTypeImeService)) Prefs.fytCount(this@GhostTypeImeService) else 1
            repeat(repeats) { input?.commitText(value, 1) }
            if (shift && !capsLock) { shift = false; invalidate() }
        }

        private fun keyboardTypeface(): Typeface = when (Prefs.font(this@GhostTypeImeService)) {
            "Monospace" -> Typeface.MONOSPACE
            "Sans Serif" -> Typeface.create("sans-serif", Typeface.NORMAL)
            else -> Typeface.DEFAULT
        }
    }
}