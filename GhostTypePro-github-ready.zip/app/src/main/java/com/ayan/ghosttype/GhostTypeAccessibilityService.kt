package com.ayan.ghosttype

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Semantic send-button adapter shared by Auto-Type and all supported messaging
 * apps. It scores a complete accessibility tree before clicking anything.
 */
class GhostTypeAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: GhostTypeAccessibilityService? = null
            private set

        fun clickVisibleSendButton(): Boolean {
            val service = instance ?: return false
            return service.clickBestSendControl()
        }
    }

    private var activePackage: String = ""
    private var lastSuccessfulClickAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        activePackage = event?.packageName?.toString().orEmpty()
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private data class Candidate(
        val node: AccessibilityNodeInfo,
        val score: Int,
        val bounds: Rect,
    )

    private fun clickBestSendControl(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (!hasEditableTarget(root)) return false
        val candidates = mutableListOf<Candidate>()
        collectCandidates(root, candidates)
        val best = candidates.maxByOrNull { it.score } ?: return false

        // A score threshold prevents generic buttons from being clicked just
        // because they happen to be visible near the input field.
        if (best.score < 55 || !best.node.isVisibleToUser || !best.node.isEnabled) return false
        if (performSemanticClick(best.node)) {
            lastSuccessfulClickAt = System.currentTimeMillis()
            return true
        }
        return performSafeGesture(best)
    }

    private fun hasEditableTarget(node: AccessibilityNodeInfo): Boolean {
        if (node.isVisibleToUser && node.isEditable) return true
        for (index in 0 until node.childCount) {
            val child = node.getChild(index) ?: continue
            if (hasEditableTarget(child)) return true
        }
        return false
    }

    private fun collectCandidates(node: AccessibilityNodeInfo, output: MutableList<Candidate>) {
        if (node.isVisibleToUser && node.isEnabled) {
            val score = scoreNode(node)
            if (score > 0) {
                val bounds = Rect().also { node.getBoundsInScreen(it) }
                output += Candidate(node, score, bounds)
            }
        }
        for (index in 0 until node.childCount) {
            node.getChild(index)?.let { child ->
                collectCandidates(child, output)
            }
        }
    }

    private fun scoreNode(node: AccessibilityNodeInfo): Int {
        val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".trim().lowercase()
        val id = node.viewIdResourceName?.lowercase().orEmpty()
        val className = node.className?.toString()?.lowercase().orEmpty()
        val packageName = node.packageName?.toString()?.lowercase()
            ?: activePackage.lowercase()

        val exactLabels = setOf(
            "send", "send message", "send now", "post", "share",
            "reply", "message", "done", "отправить", "enviar", "envoyer",
        )
        val labelHit = exactLabels.any { label == it || label.startsWith("$it ") }
        val partialHit = listOf("send_message", "sendmessage", "send_button", "submit")
            .any { label.contains(it) || id.contains(it) }
        val packageHint = when {
            packageName.contains("whatsapp") ->
                id.contains("send") || id.contains("voice_note")
            packageName.contains("instagram") ->
                id.contains("send") || id.contains("direct")
            packageName.contains("messenger") || packageName.contains("facebook") ->
                id.contains("send") || id.contains("composer")
            else -> false
        }

        var score = 0
        if (labelHit) score += 50
        if (partialHit) score += 30
        if (packageHint) score += 22
        if (id.contains("send") || id.contains("submit")) score += 24
        if (className.contains("button") || className.contains("imagebutton")) score += 8
        if (node.isClickable) score += 12
        if (node.isFocusable) score += 2
        if (label.isBlank() && !id.contains("send") && !packageHint) return 0
        if (!node.isClickable && node.parent == null) score = 0
        return score
    }

    private fun performSemanticClick(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        var parent = node.parent
        repeat(4) {
            if (parent != null && parent.isVisibleToUser && parent.isEnabled &&
                parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) {
                return true
            }
            parent = parent?.parent
        }
        return false
    }

    private fun performSafeGesture(candidate: Candidate): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false
        }
        val bounds = candidate.bounds
        if (bounds.isEmpty || bounds.width() < 4 || bounds.height() < 4) return false
        val path = Path().apply {
            moveTo(bounds.exactCenterX(), bounds.exactCenterY())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0L,
                    80L,
                ),
            )
            .build()
        return dispatchGesture(gesture, null, null)
    }
}