package com.ayan.ghosttype

/**
 * Persisted Auto-Type lifecycle. STOPPED is intentionally different from IDLE:
 * it means a task exists and START should continue from its saved cursor.
 */
enum class AutoTypeState {
    IDLE,
    RUNNING,
    PAUSED,
    STOPPED,
    COMPLETED,
}