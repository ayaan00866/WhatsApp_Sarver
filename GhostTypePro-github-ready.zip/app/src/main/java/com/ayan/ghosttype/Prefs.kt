package com.ayan.ghosttype

import android.content.Context

object Prefs {
    private const val FILE = "ghosttype_preferences"
    private const val DARK = "dark_theme"
    private const val MESSAGES = "messages"
    private const val TARGET = "target_name"
    private const val MESSAGE_DELAY = "message_delay"
    private const val CHAR_DELAY = "char_delay"
    private const val SEND_METHOD = "send_method"
    private const val AUTO_SEND = "auto_send"
    private const val LOOP = "loop"
    private const val FYT_ENABLED = "fyt_enabled"
    private const val FYT_COUNT = "fyt_count"
    private const val FYT_WORDS = "fyt_words"
    private const val KEY_HEIGHT = "key_height"
    private const val KEY_SIZE = "key_size"
    private const val FONT = "font"
    private const val CLIPBOARD_HISTORY = "clipboard_history"
    private const val HAPTIC = "haptic"
    private const val SOUND = "sound"
    private const val VIBRATION = "vibration"
    private const val LANGUAGE = "language"
    private const val NUMBER_ROW = "number_row"
    private const val EMOJI_KEY = "emoji_key"
    private const val AUTO_STATE = "auto_state"
    private const val AUTO_LINE_INDEX = "auto_line_index"
    private const val AUTO_CHAR_INDEX = "auto_char_index"
    private const val AUTO_TASK_SIGNATURE = "auto_task_signature"

    private fun p(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isDark(context: Context) = p(context).getBoolean(DARK, true)
    fun setDark(context: Context, value: Boolean) = p(context).edit().putBoolean(DARK, value).apply()

    fun messages(context: Context) = p(context).getString(MESSAGES, "") ?: ""
    fun setMessages(context: Context, value: String) = p(context).edit().putString(MESSAGES, value).apply()
    fun target(context: Context) = p(context).getString(TARGET, "") ?: ""
    fun setTarget(context: Context, value: String) = p(context).edit().putString(TARGET, value).apply()
    fun messageDelay(context: Context) = p(context).getInt(MESSAGE_DELAY, 5)
    fun setMessageDelay(context: Context, value: Int) = p(context).edit().putInt(MESSAGE_DELAY, value.coerceIn(0, 60)).apply()
    fun charDelay(context: Context) = p(context).getInt(CHAR_DELAY, 35)
    fun setCharDelay(context: Context, value: Int) = p(context).edit().putInt(CHAR_DELAY, value.coerceIn(10, 250)).apply()
    fun sendMethod(context: Context) = p(context).getString(SEND_METHOD, "auto") ?: "auto"
    fun setSendMethod(context: Context, value: String) = p(context).edit().putString(SEND_METHOD, value).apply()
    fun autoSend(context: Context) = p(context).getBoolean(AUTO_SEND, true)
    fun setAutoSend(context: Context, value: Boolean) = p(context).edit().putBoolean(AUTO_SEND, value).apply()
    fun loop(context: Context) = p(context).getBoolean(LOOP, false)
    fun setLoop(context: Context, value: Boolean) = p(context).edit().putBoolean(LOOP, value).apply()

    fun fytEnabled(context: Context) = p(context).getBoolean(FYT_ENABLED, false)
    fun setFytEnabled(context: Context, value: Boolean) = p(context).edit().putBoolean(FYT_ENABLED, value).apply()
    fun fytCount(context: Context) = p(context).getInt(FYT_COUNT, 3)
    fun setFytCount(context: Context, value: Int) = p(context).edit().putInt(FYT_COUNT, value.coerceIn(1, 10)).apply()
    fun fytWords(context: Context) = p(context).getString(FYT_WORDS, "") ?: ""
    fun setFytWords(context: Context, value: String) = p(context).edit().putString(FYT_WORDS, value).apply()

    fun keyHeight(context: Context) = p(context).getInt(KEY_HEIGHT, 100)
    fun setKeyHeight(context: Context, value: Int) = p(context).edit().putInt(KEY_HEIGHT, value.coerceIn(75, 140)).apply()
    fun keySize(context: Context) = p(context).getInt(KEY_SIZE, 100)
    fun setKeySize(context: Context, value: Int) = p(context).edit().putInt(KEY_SIZE, value.coerceIn(85, 120)).apply()
    fun font(context: Context) = p(context).getString(FONT, "System") ?: "System"
    fun setFont(context: Context, value: String) = p(context).edit().putString(FONT, value).apply()
    fun clipboardHistory(context: Context): List<String> =
        p(context).getString(CLIPBOARD_HISTORY, "").orEmpty()
            .split("\u001E")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(8)

    fun rememberClipboard(context: Context, value: String) {
        val items = (listOf(value) + clipboardHistory(context))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(8)
        p(context).edit().putString(CLIPBOARD_HISTORY, items.joinToString("\u001E")).apply()
    }
    fun haptic(context: Context) = p(context).getBoolean(HAPTIC, true)
    fun setHaptic(context: Context, value: Boolean) = p(context).edit().putBoolean(HAPTIC, value).apply()
    fun sound(context: Context) = p(context).getBoolean(SOUND, false)
    fun setSound(context: Context, value: Boolean) = p(context).edit().putBoolean(SOUND, value).apply()
    fun vibration(context: Context) = p(context).getInt(VIBRATION, 50)
    fun setVibration(context: Context, value: Int) = p(context).edit().putInt(VIBRATION, value).apply()
    fun language(context: Context) = p(context).getString(LANGUAGE, "English (US)") ?: "English (US)"
    fun setLanguage(context: Context, value: String) = p(context).edit().putString(LANGUAGE, value).apply()
    fun numberRow(context: Context) = p(context).getBoolean(NUMBER_ROW, true)
    fun setNumberRow(context: Context, value: Boolean) = p(context).edit().putBoolean(NUMBER_ROW, value).apply()
    fun emojiKey(context: Context) = p(context).getBoolean(EMOJI_KEY, true)
    fun setEmojiKey(context: Context, value: Boolean) = p(context).edit().putBoolean(EMOJI_KEY, value).apply()

    fun autoState(context: Context) = p(context).getString(AUTO_STATE, AutoTypeState.IDLE.name)
        ?.let { runCatching { AutoTypeState.valueOf(it) }.getOrDefault(AutoTypeState.IDLE) }
        ?: AutoTypeState.IDLE

    fun setAutoState(context: Context, value: AutoTypeState) =
        p(context).edit().putString(AUTO_STATE, value.name).apply()

    fun autoLineIndex(context: Context) = p(context).getInt(AUTO_LINE_INDEX, 0)
    fun setAutoLineIndex(context: Context, value: Int) =
        p(context).edit().putInt(AUTO_LINE_INDEX, value.coerceAtLeast(0)).apply()

    fun autoCharIndex(context: Context) = p(context).getInt(AUTO_CHAR_INDEX, 0)
    fun setAutoCharIndex(context: Context, value: Int) =
        p(context).edit().putInt(AUTO_CHAR_INDEX, value.coerceAtLeast(0)).apply()

    fun autoTaskSignature(context: Context) = p(context).getString(AUTO_TASK_SIGNATURE, "") ?: ""
    fun setAutoTaskSignature(context: Context, value: String) =
        p(context).edit().putString(AUTO_TASK_SIGNATURE, value).apply()

    fun resetAutoProgress(context: Context) {
        p(context).edit()
            .putString(AUTO_STATE, AutoTypeState.IDLE.name)
            .putInt(AUTO_LINE_INDEX, 0)
            .putInt(AUTO_CHAR_INDEX, 0)
            .remove(AUTO_TASK_SIGNATURE)
            .apply()
    }

    fun reset(context: Context) = p(context).edit().clear().putBoolean(DARK, true).apply()
}