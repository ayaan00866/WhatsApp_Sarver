package com.ayan.ghosttype

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import kotlin.math.roundToInt

class MainActivity : Activity() {
    companion object {
        const val EXTRA_OPEN_PAGE = "com.ayan.ghosttype.OPEN_PAGE"
    }

    private enum class Page { HOME, AUTO_TYPE, FYT, KEYBOARD, DEVELOPER, ABOUT, RESET }
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private var drawer: LinearLayout? = null
    private var drawerScrim: View? = null
    private var activeCard: LinearLayout? = null
    private var page = Page.HOME
    private var fileRequest = 2001
    private var contentScroll: ScrollView? = null
    private var headerNav: TextView? = null
    private var headerTitle: TextView? = null
    private var headerSubtitle: TextView? = null

    private val dark get() = Prefs.isDark(this)
    private val bg get() = if (dark) Color.rgb(7, 7, 12) else Color.rgb(246, 244, 252)
    private val surface get() = if (dark) Color.rgb(16, 17, 25) else Color.rgb(253, 252, 255)
    private val raised get() = if (dark) Color.rgb(29, 30, 41) else Color.rgb(235, 232, 247)
    private val text get() = if (dark) Color.rgb(244, 242, 250) else Color.rgb(25, 23, 36)
    private val muted get() = if (dark) Color.rgb(164, 162, 183) else Color.rgb(91, 86, 112)
    private val accent get() = if (dark) Color.rgb(177, 118, 255) else Color.rgb(112, 64, 190)
    private val border get() = if (dark) Color.rgb(88, 70, 157) else Color.rgb(184, 162, 224)
    private val goldWash get() = if (dark) Color.rgb(40, 27, 58) else Color.rgb(243, 236, 255)
    private val iceWash get() = if (dark) Color.rgb(20, 29, 58) else Color.rgb(232, 237, 255)
    private val success = Color.rgb(84, 207, 174)
    private val danger = Color.rgb(220, 75, 78)

    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        buildShell()
        showPage(if (intent?.getStringExtra(EXTRA_OPEN_PAGE) == "keyboard") Page.KEYBOARD else Page.HOME)
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && page == Page.HOME) showPage(Page.HOME)
    }

    override fun onBackPressed() {
        if (drawer?.visibility == View.VISIBLE) closeDrawer() else super.onBackPressed()
    }

    private fun buildShell() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true)
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        } else {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (dark) {
            0
        } else {
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(18), dp(8))
            setBackgroundColor(bg)
        }
        val menu = TextView(this).apply {
            text = "☰"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(accent)
            contentDescription = "Open navigation"
            setOnClickListener { if (page == Page.HOME) openDrawer() else showPage(Page.HOME) }
            background = rounded(Color.TRANSPARENT, 18, border)
        }
        headerNav = menu
        bar.addView(menu, LinearLayout.LayoutParams(dp(42), dp(48)))
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ghosttype_icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "Auto Typer logo"
        }
        bar.addView(logo, LinearLayout.LayoutParams(dp(42), dp(48)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), 0, 0, 0)
        }
        val titleView = TextView(this).apply {
            text = "Auto Typer"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(this@MainActivity.text)
        }
        val subtitleView = TextView(this).apply {
            text = "Type Faster  •  Work Smarter"
            textSize = 9f
            setTextColor(muted)
        }
        headerTitle = titleView
        headerSubtitle = subtitleView
        brand.addView(titleView, LinearLayout.LayoutParams(-1, dp(25)))
        brand.addView(subtitleView, LinearLayout.LayoutParams(-1, dp(18)))
        bar.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        val theme = TextView(this).apply {
            text = if (dark) "☾" else "☀"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(this@MainActivity.text)
            contentDescription = "Switch theme"
            background = gradientSurface(raised, 22)
            setOnClickListener { setThemeMode(!dark) }
        }
        bar.addView(theme, LinearLayout.LayoutParams(dp(44), dp(44)))
        shell.addView(bar, LinearLayout.LayoutParams(-1, dp(60)))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(16), dp(4), dp(16), dp(28))
        }
        contentScroll = scroll
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(28))
        }
        scroll.addView(content)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { view, insets ->
            applyImeInsets(view, insets)
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    private fun applyImeInsets(view: View, insets: android.view.WindowInsets): android.view.WindowInsets {
        val keyboardBottom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (insets.isVisible(android.view.WindowInsets.Type.ime())) {
                insets.getInsets(android.view.WindowInsets.Type.ime()).bottom
            } else {
                0
            }
        } else {
            insets.systemWindowInsetBottom.takeIf { it > dp(80) } ?: 0
        }
        if (view.paddingBottom != keyboardBottom) {
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, keyboardBottom)
        }
        if (keyboardBottom > 0) {
            contentScroll?.post {
                contentScroll?.let { ensureFocusedEditorVisible(it) }
            }
        }
        return insets
    }

    private fun ensureFocusedEditorVisible(scroll: ScrollView) {
        val focused = currentFocus ?: return
        if (focused !is EditText || !focused.isShown) return
        val rect = Rect()
        runCatching { scroll.offsetDescendantRectToMyCoords(focused, rect) }.getOrNull() ?: return
        val margin = dp(16)
        val visibleTop = scroll.paddingTop + margin
        val visibleBottom = scroll.height - scroll.paddingBottom - margin
        when {
            rect.bottom > visibleBottom -> {
                scroll.smoothScrollBy(0, rect.bottom - visibleBottom)
            }
            rect.top < visibleTop -> {
                scroll.smoothScrollBy(0, rect.top - visibleTop)
            }
        }
    }

    private fun openDrawer() {
        drawer?.let { root.removeView(it) }
        drawerScrim?.let { root.removeView(it) }
        val scrim = View(this).apply {
            setBackgroundColor(Color.argb(if (dark) 150 else 90, 0, 0, 0))
            setOnClickListener { closeDrawer() }
        }
        drawerScrim = scrim
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(18))
            background = gradientSurface(surface, 0)
            elevation = dp(14).toFloat()
        }
        val heading = TextView(this).apply {
            text = "Auto Typer"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            setPadding(0, 0, 0, dp(22))
        }
        overlay.addView(heading, LinearLayout.LayoutParams(-1, -2))
        overlay.addView(TextView(this).apply {
            text = "NAVIGATION"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            letterSpacing = 0.12f
            setPadding(0, 0, 0, dp(8))
        }, LinearLayout.LayoutParams(-1, dp(24)))
        val items = listOf(
            "Home" to Page.HOME,
            "Auto-Type" to Page.AUTO_TYPE,
            "FYT Type" to Page.FYT,
            "Keyboard" to Page.KEYBOARD,
            "Developer" to Page.DEVELOPER,
            "About" to Page.ABOUT
        )
        items.forEach { (label, destination) ->
            val item = drawerItem(label, destination == page)
            item.setOnClickListener { closeDrawer(); showPage(destination) }
            overlay.addView(item, LinearLayout.LayoutParams(-1, dp(56)).apply {
                setMargins(0, 0, 0, dp(8))
            })
        }
        val spacer = Space(this)
        overlay.addView(spacer, LinearLayout.LayoutParams(-1, 0, 1f))
        overlay.addView(TextView(this).apply {
            text = "APPEARANCE"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, dp(24)))
        val themeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        themeRow.addView(themeChoice("☾  Dark", dark) { setThemeMode(true) },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0, 0, dp(5), 0) })
        themeRow.addView(themeChoice("☀  Light", !dark) { setThemeMode(false) },
            LinearLayout.LayoutParams(0, dp(46), 1f))
        overlay.addView(themeRow, LinearLayout.LayoutParams(-1, dp(52)))
        overlay.addView(TextView(this).apply {
            text = "Auto Typer  •  v1.0.12"
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, dp(28)))
        drawer = overlay
        root.addView(overlay, FrameLayout.LayoutParams(dp(310), -1).apply { gravity = Gravity.START })
    }

    private fun closeDrawer() {
        drawer?.visibility = View.GONE
        drawerScrim?.visibility = View.GONE
    }

    private fun setThemeMode(useDark: Boolean) {
        if (Prefs.isDark(this) == useDark) return
        Prefs.setDark(this, useDark)
        closeDrawer()
        buildShell()
        showPage(page)
    }

    private fun themeChoice(label: String, selected: Boolean, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(if (selected) Color.rgb(7, 15, 24) else this@MainActivity.text)
            background = if (selected) gradientButton(blue, accent, 14) else gradientSurface(raised, 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }

    private fun drawerItem(label: String, selected: Boolean): LinearLayout {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(12), 0)
            isClickable = true
            isFocusable = true
            background = if (selected) {
                gradientButton(blue, accent, 12)
            } else {
                gradientSurface(surface, 12)
            }
        }
        val icon = ImageView(this).apply {
            setImageResource(drawerIcon(label))
            setColorFilter(if (selected) bg else muted)
            contentDescription = label
        }
        item.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))
        val title = TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(if (selected) bg else this@MainActivity.text)
            setPadding(dp(12), 0, 0, 0)
        }
        item.addView(title, LinearLayout.LayoutParams(0, -1, 1f))
        return item
    }

    private fun drawerIcon(label: String): Int = when {
        label.contains("Home", ignoreCase = true) -> android.R.drawable.ic_menu_view
        label.contains("Auto", ignoreCase = true) -> android.R.drawable.ic_media_play
        label.contains("FYT", ignoreCase = true) -> android.R.drawable.ic_menu_rotate
        label.contains("Keyboard", ignoreCase = true) -> android.R.drawable.ic_menu_manage
        label.contains("Developer", ignoreCase = true) -> android.R.drawable.ic_menu_edit
        label.contains("About", ignoreCase = true) -> android.R.drawable.ic_menu_info_details
        label.contains("Light", ignoreCase = true) -> android.R.drawable.ic_menu_preferences
        else -> android.R.drawable.ic_menu_preferences
    }

    private fun showPage(destination: Page) {
        page = destination
        headerNav?.let {
            it.text = if (destination == Page.HOME) "☰" else "‹"
            it.textSize = if (destination == Page.HOME) 25f else 34f
            it.contentDescription = if (destination == Page.HOME) "Open navigation" else "Back to home"
            it.setOnClickListener { if (destination == Page.HOME) openDrawer() else showPage(Page.HOME) }
        }
        content.removeAllViews()
        when (destination) {
            Page.HOME -> homePage()
            Page.AUTO_TYPE -> autoTypePage()
            Page.FYT -> fytPage()
            Page.KEYBOARD -> keyboardSettingsPage()
            Page.DEVELOPER -> developerPage()
            Page.ABOUT -> aboutPage()
            Page.RESET -> resetPage()
        }
    }

    private fun homePage() {
        heroBanner(
            "Auto-Type",
            "A premium Android keyboard with Auto-Type engine,\nclipboard manager and focused typing tools.",
            "⚡",
            "Fast  •  Simple  •  Reliable",
        )
        val setupCount = listOf(imeEnabled(), defaultIme(), accessibilityEnabled()).count { it }
        card {
            val header = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            header.addView(sectionTitle("Setup required"), LinearLayout.LayoutParams(0, dp(30), 1f))
            header.addView(pill("$setupCount/3"), LinearLayout.LayoutParams(dp(52), dp(28)))
            addView(header, LinearLayout.LayoutParams(-1, dp(34)))
            body("Complete the steps below to activate the keyboard.")
            addView(outlineButton("↻  Re-check status") { showPage(Page.HOME) }, LinearLayout.LayoutParams(dp(154), dp(42)))
        }
        setupStep(1, "Enable the keyboard", imeEnabled(), "Go to System Settings → Languages & Input → Manage Keyboards and toggle Auto Typer ON.") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        setupStep(2, "Set as default input method", defaultIme(), "Tap any text field and select Auto Typer from the input method picker, or long-press the spacebar.") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        setupStep(3, "Grant Accessibility permission", accessibilityEnabled(), "Required for Auto-Type to detect and tap the Send button in messaging apps.") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        card {
            title("Ready when you are")
            body("Auto Typer never starts automation on its own. Press START from the keyboard panel whenever you want to enter your saved lines.")
        }
    }

    private fun setupStep(number: Int, label: String, done: Boolean, description: String, action: () -> Unit) {
        card(backgroundColor = if (done) Color.rgb(11, 48, 54) else surface) {
            val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            val copy = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            val step = TextView(this@MainActivity).apply {
                text = number.toString()
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = gradientButton(blue, accent, 20)
            }
            copy.addView(step, LinearLayout.LayoutParams(dp(32), dp(32)).apply { setMargins(0, 0, dp(10), 0) })
            val stepLabel = TextView(this@MainActivity).apply {
                text = label
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(this@MainActivity.text)
            }
            copy.addView(stepLabel, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            val badge = TextView(this@MainActivity).apply {
                text = if (done) "✓ Done" else "Pending"
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (done) success else Color.rgb(201, 159, 255))
                gravity = Gravity.CENTER
                background = rounded(if (done) Color.argb(42, 84, 207, 174) else Color.argb(45, 177, 118, 255), 14, null)
                setPadding(dp(10), 0, dp(10), 0)
            }
            row.addView(badge)
            addView(row, LinearLayout.LayoutParams(-1, -2))
            body(description)
            addView(button(if (done) "Open Settings" else when (number) {
                1 -> "Open Keyboard Settings"
                2 -> "Open Input Picker"
                else -> "Open Accessibility Settings"
            }, action), LinearLayout.LayoutParams(-2, dp(48)))
        }
    }

    private fun autoTypePage() {
        heading("Auto-Type", "Create a precise, repeatable message sequence")
        statusBanner(if (imeEnabled() && defaultIme()) "Auto Typer keyboard active" else "Auto Typer keyboard not active", imeEnabled() && defaultIme())
        var target: EditText? = null
        var messages: EditText? = null
        card {
            val header = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            header.addView(sectionTitle("Message Setup"), LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(outlineButton("Load .txt") {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "text/plain"; addCategory(Intent.CATEGORY_OPENABLE)
                }, fileRequest)
            }.apply { textSize = 9f; setPadding(0, 0, 0, 0) }, LinearLayout.LayoutParams(dp(54), dp(30)))
            addView(header, LinearLayout.LayoutParams(-1, dp(34)))
            label("Message prefix / recipient")
            target = edit("e.g. Ali", Prefs.target(this@MainActivity), false)
            addView(target, LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(0, dp(4), 0, dp(4)) })
            body("If set, every line is sent as  “Ali your message”.")
            label("Message queue")
            messages = edit("One message per line", Prefs.messages(this@MainActivity), true)
            addView(messages, LinearLayout.LayoutParams(-1, dp(110)).apply { setMargins(0, dp(4), 0, dp(10)) })
            val actions = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            val use = button("Save changes") {
                val targetName = target?.text?.toString()?.trim().orEmpty()
                Prefs.setTarget(this@MainActivity, targetName)
                Prefs.setMessages(this@MainActivity, messages?.text?.toString().orEmpty())
                Toast.makeText(this@MainActivity, "Message setup saved", Toast.LENGTH_SHORT).show()
            }
            actions.addView(use, LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(0, 0, dp(6), 0) })
            val clear = outlineButton("Clear queue") {
                messages?.setText("")
                Prefs.setMessages(this@MainActivity, "")
            }
            actions.addView(clear, LinearLayout.LayoutParams(dp(92), dp(36)))
            addView(actions, LinearLayout.LayoutParams(-1, dp(42)))
        }
        card {
            title("Delivery controls")
            val delayLine = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            delayLine.addView(lineLabel("Message delay"), LinearLayout.LayoutParams(0, dp(34), 1f))
            val delayValue = TextView(this@MainActivity).apply { setTextColor(this@MainActivity.text); textSize = 15f; gravity = Gravity.CENTER }
            val minus = button("−") {
                    Prefs.setMessageDelay(this@MainActivity, Prefs.messageDelay(this@MainActivity) - 1)
                    delayValue.text = "${Prefs.messageDelay(this@MainActivity)}s"
                }.apply { setPadding(0, 0, 0, 0) }
            val plus = button("+") {
                    Prefs.setMessageDelay(this@MainActivity, Prefs.messageDelay(this@MainActivity) + 1)
                    delayValue.text = "${Prefs.messageDelay(this@MainActivity)}s"
                }.apply { setPadding(0, 0, 0, 0) }
            delayValue.text = "${Prefs.messageDelay(this@MainActivity)}s"
            delayLine.addView(minus, LinearLayout.LayoutParams(dp(28), dp(28)))
            delayLine.addView(delayValue, LinearLayout.LayoutParams(dp(38), dp(34)))
            delayLine.addView(plus, LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(delayLine, LinearLayout.LayoutParams(-1, dp(38)))
            val speedLine = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            speedLine.addView(lineLabel("Typing speed"), LinearLayout.LayoutParams(0, dp(30), 1f))
            val speedValue = TextView(this@MainActivity).apply { text = "${Prefs.charDelay(this@MainActivity)}ms/char"; textSize = 12f; setTextColor(accent); gravity = Gravity.CENTER_VERTICAL }
            speedLine.addView(speedValue, LinearLayout.LayoutParams(-2, dp(30)))
            addView(speedLine, LinearLayout.LayoutParams(-1, dp(30)))
            val speed = SeekBar(this@MainActivity).apply {
                max = 24
                progress = (Prefs.charDelay(this@MainActivity) - 10) / 10
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val value = 10 + progress * 10
                        Prefs.setCharDelay(this@MainActivity, value)
                        speedValue.text = "$value ms/char"
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                })
            }
            addView(speed, LinearLayout.LayoutParams(-1, dp(36)))
            label("Send method")
            val methodRow = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER }
            listOf("auto" to "Auto", "enter" to "Enter", "access" to "Access").forEach { (value, label) ->
                val choice = button(label) {
                    Prefs.setSendMethod(this@MainActivity, value)
                    Toast.makeText(this@MainActivity, "$label send method selected", Toast.LENGTH_SHORT).show()
                }
                methodRow.addView(choice, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            }
            addView(methodRow, LinearLayout.LayoutParams(-1, dp(52)))
            switchRow("Auto-send after each line", "Finds the visible Send control after each line.", Prefs.autoSend(this@MainActivity)) {
                Prefs.setAutoSend(this@MainActivity, it)
            }
            switchRow("Loop mode", "Repeat the queue until you press STOP.", Prefs.loop(this@MainActivity)) {
                Prefs.setLoop(this@MainActivity, it)
            }
        }
        val loaded = Prefs.messages(this).lineSequence().count { it.isNotBlank() }
        card {
            addView(sectionTitle(if (loaded == 0) "Queue is empty" else "$loaded messages ready"), LinearLayout.LayoutParams(-1, dp(30)))
            val controls = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            val start = button("▶ Start") {
                if (imeEnabled() && defaultIme()) {
                    sendAutoCommand(GhostTypeImeService.ACTION_START_AUTO_TYPE)
                } else {
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                    Toast.makeText(this@MainActivity, "Select Auto Typer, then focus a text field", Toast.LENGTH_SHORT).show()
                }
            }
            val pause = button("▣ Pause") {
                sendAutoCommand(GhostTypeImeService.ACTION_PAUSE_AUTO_TYPE)
            }
            val stop = outlineButton("■ Stop") {
                sendAutoCommand(GhostTypeImeService.ACTION_STOP_AUTO_TYPE)
            }
            listOf(start, pause, stop).forEach {
                it.isEnabled = loaded > 0
                it.alpha = if (loaded > 0) 1f else 0.35f
            }
            controls.addView(start, LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(0, 0, dp(6), 0) })
            controls.addView(pause, LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(0, 0, dp(6), 0) })
            controls.addView(stop, LinearLayout.LayoutParams(0, dp(36), 1f))
            addView(controls, LinearLayout.LayoutParams(-1, dp(42)))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val value = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                Prefs.setMessages(this, value)
                if (page == Page.AUTO_TYPE) showPage(Page.AUTO_TYPE)
                Toast.makeText(this, "Text file loaded", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Could not read that text file", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun fytPage() {
        heading("FYT Type", "Repeat each character while you type")
        card {
            title("FYT Mode")
            switchRow("FYT mode", "OFF — types normally", Prefs.fytEnabled(this@MainActivity)) {
                Prefs.setFytEnabled(this@MainActivity, it)
            }
            val warning = TextView(this@MainActivity).apply {
                text = if (imeEnabled()) "Ready to use from the Auto Typer keyboard" else "Open Auto Typer keyboard first"
                textSize = 12f
                setTextColor(if (imeEnabled()) success else danger)
                setPadding(0, dp(8), 0, 0)
            }
            addView(warning)
        }
        card {
            title("Type Count")
            body("Each character repeats this many times")
            val count = TextView(this@MainActivity).apply { text = Prefs.fytCount(this@MainActivity).toString(); textSize = 17f; setTextColor(accent); gravity = Gravity.CENTER }
            addView(controlRow(
                button("−") { Prefs.setFytCount(this@MainActivity, Prefs.fytCount(this@MainActivity) - 1); count.text = Prefs.fytCount(this@MainActivity).toString() },
                count,
                button("+") { Prefs.setFytCount(this@MainActivity, Prefs.fytCount(this@MainActivity) + 1); count.text = Prefs.fytCount(this@MainActivity).toString() }
            ), LinearLayout.LayoutParams(-1, dp(54)))
        }
        card {
            title("Your Words")
            body("One word per line")
            val words = edit("hello\nthanks\ngoodbye", Prefs.fytWords(this@MainActivity), true)
            addView(words, LinearLayout.LayoutParams(-1, dp(150)))
            addView(button("Save words") { Prefs.setFytWords(this@MainActivity, words.text.toString()); Toast.makeText(this@MainActivity, "Words saved", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, dp(48)))
        }
    }

    private fun keyboardSettingsPage() {
        heading("Keyboard Settings", "Make the keyboard fit your hands")
        card {
            title("Keyboard size")
            seekPreference("Key width", Prefs.keySize(this@MainActivity), 85, 120) { Prefs.setKeySize(this@MainActivity, it) }
            seekPreference("Keyboard height", Prefs.keyHeight(this@MainActivity), 75, 140) { Prefs.setKeyHeight(this@MainActivity, it) }
            label("Font selection")
            val font = Spinner(this@MainActivity).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("System", "Sans Serif", "Monospace"))
                setSelection(listOf("System", "Sans Serif", "Monospace").indexOf(Prefs.font(this@MainActivity)).coerceAtLeast(0))
                background = gradientSurface(raised, 10)
                setPadding(dp(12), 0, dp(10), 0)
                onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                        Prefs.setFont(this@MainActivity, parent?.getItemAtPosition(position).toString())
                    }
                }
            }
            addView(font, LinearLayout.LayoutParams(-1, dp(52)))
        }
        card {
            title("Typing feedback")
            switchRow("Haptic feedback", "Vibrate on key press when supported.", Prefs.haptic(this@MainActivity)) { Prefs.setHaptic(this@MainActivity, it) }
            switchRow("Key sound", "Play a sound on key press when supported.", Prefs.sound(this@MainActivity)) { Prefs.setSound(this@MainActivity, it) }
            seekPreference("Vibration strength", Prefs.vibration(this@MainActivity), 0, 100) { Prefs.setVibration(this@MainActivity, it) }
        }
        card {
            title("Layout")
            label("Language / layout selection")
            val language = Spinner(this@MainActivity).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("English (US)", "English (UK)"))
                setSelection(if (Prefs.language(this@MainActivity).contains("UK")) 1 else 0)
                background = gradientSurface(raised, 10)
                setPadding(dp(12), 0, dp(10), 0)
                onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                        Prefs.setLanguage(this@MainActivity, parent?.getItemAtPosition(position).toString())
                    }
                }
            }
            addView(language, LinearLayout.LayoutParams(-1, dp(52)))
            switchRow("Number row", "Show 1–0 above the letters.", Prefs.numberRow(this@MainActivity)) { Prefs.setNumberRow(this@MainActivity, it) }
            switchRow("Emoji key", "Show the emoji shortcut beside the space bar.", Prefs.emojiKey(this@MainActivity)) { Prefs.setEmojiKey(this@MainActivity, it) }
        }
        card {
            title("Theme")
            addView(button(if (dark) "Dark theme active" else "Light theme active") {
                setThemeMode(!dark)
            }, LinearLayout.LayoutParams(-1, dp(48)))
            addView(button("Reset Settings") { showPage(Page.RESET) }, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(0, dp(8), 0, 0) })
        }
    }

    private fun resetPage() {
        heading("Reset Settings", "Return Auto Typer to its original defaults")
        card {
            body("Restore the app to its original factory defaults. All your customisations will be erased.")
        }
        card {
            title("What will be reset")
            body("⌨  Keyboard size, font, haptic, sound\n\n🤖  Auto-Type settings & target name\n\n👤  Plans, name, active plan\n\n🔧  All other app preferences")
            val reset = button("↻  Reset All Settings") {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Reset all settings?")
                    .setMessage("All data will be permanently deleted. This cannot be undone. Android's keyboard selection will not be changed.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Reset") { _, _ ->
                        Prefs.reset(this@MainActivity)
                        buildShell()
                        showPage(Page.HOME)
                    }.show()
            }
            reset.setTextColor(Color.WHITE)
            reset.background = rounded(danger, 12, null)
            addView(reset, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(12), 0, 0) })
        }
        card {
            val warning = TextView(this@MainActivity).apply {
                text = "⚠  All data will be permanently deleted. This cannot be undone."
                textSize = 13f
                setTextColor(danger)
            }
            addView(warning)
        }
    }

    private fun developerPage() {
        heading("Developer", "Auto Typer creator")
        card {
            val profile = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
            val avatar = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ayan_profile)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(raised, 48, accent)
                contentDescription = "Ayan profile"
            }
            profile.addView(avatar, LinearLayout.LayoutParams(dp(74), dp(74)))
            val copy = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, 0, 0)
            }
            copy.addView(TextView(this@MainActivity).apply {
                text = "AYAN"
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(this@MainActivity.text)
            })
            copy.addView(TextView(this@MainActivity).apply {
                text = "Android Developer & Content Creator"
                textSize = 12f
                setTextColor(muted)
                setPadding(0, dp(4), 0, dp(4))
            })
            copy.addView(TextView(this@MainActivity).apply {
                text = "●  Active developer"
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(success)
            })
            profile.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            addView(profile, LinearLayout.LayoutParams(-1, dp(78)))
        }
        card {
            title("About me")
            body("I build focused Android tools that keep the user in control. Auto Typer is designed to make repetitive text entry clearer, safer and easier to customize.")
            body("My goal is to keep building useful apps for the community — combining thoughtful automation, clean interaction design and dependable Android engineering.")
        }
        card {
            val highlights = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER
            }
            listOf(
                "⌨" to "Auto Typer",
                "⚙" to "IME Tools",
                "▣" to "Android"
            ).forEach { (icon, labelValue) ->
                val tile = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(raised, 14, border)
                    setPadding(dp(4), dp(8), dp(4), dp(8))
                }
                tile.addView(TextView(this@MainActivity).apply {
                    text = icon
                    textSize = 20f
                    gravity = Gravity.CENTER
                    setTextColor(accent)
                }, LinearLayout.LayoutParams(-1, dp(26)))
                tile.addView(TextView(this@MainActivity).apply {
                    text = labelValue
                    textSize = 10f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(this@MainActivity.text)
                }, LinearLayout.LayoutParams(-1, dp(24)))
                highlights.addView(tile, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                })
            }
            addView(highlights, LinearLayout.LayoutParams(-1, dp(72)))
        }
        card {
            title("Skills & Tech")
            progress("Kotlin", 0.90f)
            progress("Jetpack / Android", 0.86f)
            progress("Android IME", 0.92f)
            progress("Auto-Type Engine", 0.95f)
            progress("UI/UX Design", 0.80f)
        }
        card(backgroundColor = goldWash) {
            val quote = TextView(this@MainActivity).apply {
                text = "“Build tools that solve real problems. Keep it simple, keep it powerful.”"
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                setTextColor(this@MainActivity.text)
                setLineSpacing(2f, 1.08f)
            }
            addView(quote, LinearLayout.LayoutParams(-1, -2))
            label("— AYAN")
        }
        footer()
    }

    private fun aboutPage() {
        heading("About", "Auto Typer")
        card(backgroundColor = surface) {
            val icon = ImageView(this@MainActivity).apply {
                setImageResource(R.mipmap.ghosttype_icon)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                background = rounded(raised, 22, accent)
                contentDescription = "Auto Typer icon"
            }
            addView(icon, LinearLayout.LayoutParams(dp(78), dp(78)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setMargins(0, 0, 0, dp(12))
            })
            addView(TextView(this@MainActivity).apply {
                text = "Auto Typer"
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(accent)
            }, LinearLayout.LayoutParams(-1, dp(32)))
            val pills = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER }
            pills.addView(pill("v1.0.12"), LinearLayout.LayoutParams(-2, dp(30)).apply {
                setMargins(0, 0, dp(6), 0)
            })
            pills.addView(pill("Android 7.0+"), LinearLayout.LayoutParams(-2, dp(30)))
            addView(pills, LinearLayout.LayoutParams(-1, dp(36)))
            addView(TextView(this@MainActivity).apply {
                text = "Professional Keyboard  •  Auto-Type Engine"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(muted)
            }, LinearLayout.LayoutParams(-1, dp(24)))
        }
        card {
            title("Developer")
            val profile = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
            val avatar = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ayan_profile)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(raised, 40, accent)
                contentDescription = "Ayan profile"
            }
            profile.addView(avatar, LinearLayout.LayoutParams(dp(54), dp(54)))
            val copy = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, 0, 0)
            }
            copy.addView(TextView(this@MainActivity).apply {
                text = "AYAN"
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(this@MainActivity.text)
            })
            copy.addView(TextView(this@MainActivity).apply {
                text = "Auto Typer Developer"
                textSize = 12f
                setTextColor(muted)
                setPadding(0, dp(3), 0, dp(4))
            })
            copy.addView(TextView(this@MainActivity).apply {
                text = "●  Active developer"
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(success)
            })
            profile.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            addView(profile, LinearLayout.LayoutParams(-1, dp(58)))
        }
        card {
            title("Features")
            featureRow("⌨", "IME Keyboard Service")
            featureRow("▶", "Auto-Type Engine")
            featureRow("✦", "Custom Keyboard Themes")
            featureRow("▣", "Clipboard History")
            featureRow("↻", "FYT Type & Multi-language")
        }
        card {
            title("Connect with us")
            body("Have a question or want to share feedback? WhatsApp is the contact channel included in this build.")
            addView(button("WhatsApp  •  8126800625") {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?phone=918126800625")))
                } catch (_: Exception) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/918126800625")))
                }
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        footer()
    }

    private fun footer() {
        val footer = TextView(this).apply {
            text = "Auto Typer  •  Built by Ayan"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(20), 0, dp(12))
        }
        content.addView(footer, LinearLayout.LayoutParams(-1, -2))
    }

    private fun heading(title: String, subtitle: String) {
        val glyph = when {
            title.contains("FYT", ignoreCase = true) -> "R F"
            title.contains("Keyboard", ignoreCase = true) -> "⌨"
            title.contains("Developer", ignoreCase = true) -> "</>"
            title.contains("About", ignoreCase = true) -> "i"
            else -> "➤"
        }
        heroBanner(title, subtitle, glyph)
    }

    private fun heroBanner(
        titleValue: String,
        subtitleValue: String,
        glyph: String,
        chips: String? = null,
    ) {
        card(backgroundColor = iceWash) {
            val row = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
            val copy = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 0, dp(8), 0)
            }
            copy.addView(TextView(this@MainActivity).apply {
                text = titleValue
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(accent)
            }, LinearLayout.LayoutParams(-1, dp(32)))
            copy.addView(TextView(this@MainActivity).apply {
                text = subtitleValue
                textSize = 12f
                setTextColor(this@MainActivity.text)
                setLineSpacing(1f, 1.08f)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            if (chips != null) {
                copy.addView(TextView(this@MainActivity).apply {
                    text = chips
                    textSize = 10f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = gradientButton(blue, accent, 16)
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                }, LinearLayout.LayoutParams(-2, dp(28)).apply { setMargins(0, dp(10), 0, 0) })
            }
            row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            val emblem = TextView(this@MainActivity).apply {
                text = glyph
                textSize = if (glyph.length > 2) 18f else 34f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = gradientButton(blue, accent, 22)
                elevation = dp(7).toFloat()
                setPadding(dp(9), 0, dp(9), 0)
            }
            row.addView(emblem, LinearLayout.LayoutParams(dp(86), dp(86)))
            addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun compactHeading(value: String) {
        val view = TextView(this).apply {
            text = value
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
        }
        content.addView(view, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(7), 0, dp(9)) })
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(this@MainActivity.text)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun pill(value: String) = TextView(this).apply {
        text = value
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (dark) bg else this@MainActivity.text)
        background = rounded(if (value.startsWith("v")) accent else raised, 18, border)
        setPadding(dp(12), 0, dp(12), 0)
    }

    private fun featureRow(icon: String, labelValue: String) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }
        row.addView(TextView(this).apply {
            text = icon
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(accent)
        }, LinearLayout.LayoutParams(dp(30), dp(40)))
        row.addView(TextView(this).apply {
            text = labelValue
            textSize = 13f
            setTextColor(this@MainActivity.text)
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            setMargins(dp(6), 0, 0, 0)
        })
        row.addView(TextView(this).apply {
            text = "✓"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(accent)
        }, LinearLayout.LayoutParams(dp(30), dp(40)))
        targetContainer().addView(row, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun lineLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 11f
        setTextColor(muted)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun card(
        widthDp: Int? = null,
        backgroundColor: Int = surface,
        block: LinearLayout.() -> Unit
    ) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = gradientSurface(backgroundColor, 16)
            elevation = dp(3).toFloat()
        }
        val previous = activeCard
        activeCard = item
        item.block()
        activeCard = previous
        content.addView(item, LinearLayout.LayoutParams(widthDp?.let { dp(it) } ?: -1, -2).apply { setMargins(0, 0, 0, dp(12)) })
    }

    private fun title(value: String) {
        val view = TextView(this).apply {
            text = value
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            setPadding(0, 0, 0, dp(7))
        }
        targetContainer().addView(view, LinearLayout.LayoutParams(-1, -2))
    }

    private fun whiteTitle(value: String) {
        val view = TextView(this).apply {
            text = value
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(this@MainActivity.text)
            setPadding(0, 0, 0, dp(7))
        }
        targetContainer().addView(view, LinearLayout.LayoutParams(-1, -2))
    }

    private fun label(value: String) {
        val view = TextView(this).apply { text = value; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted) }
        targetContainer().addView(view, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(2)) })
    }

    private fun body(value: String) {
        val view = TextView(this).apply { text = value; textSize = 13f; setTextColor(this@MainActivity.text); setLineSpacing(2f, 1.08f) }
        targetContainer().addView(view, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) })
    }

    private fun statusBanner(value: String, active: Boolean) {
        val view = TextView(this).apply {
            text = "●  $value"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (active) success else danger)
            background = gradientSurface(
                if (active) Color.rgb(10, 54, 61) else Color.rgb(63, 19, 42),
                14,
            )
            elevation = dp(2).toFloat()
            setPadding(dp(14), dp(13), dp(14), dp(13))
        }
        content.addView(view, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) })
    }

    private fun button(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        setTextColor(Color.WHITE)
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        gravity = Gravity.CENTER
        setPadding(dp(18), 0, dp(18), 0)
        background = gradientButton(blue, accent, 24)
        elevation = dp(3).toFloat()
        setOnClickListener { action() }
    }

    private fun outlineButton(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        setTextColor(if (dark) Color.rgb(170, 211, 255) else Color.rgb(79, 86, 190))
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        gravity = Gravity.CENTER
        background = gradientOutline(24)
        elevation = dp(2).toFloat()
        setOnClickListener { action() }
    }

    private fun edit(hintValue: String, value: String, multiline: Boolean): EditText = EditText(this).apply {
        hint = hintValue
        setText(value)
        textSize = 14f
        setTextColor(this@MainActivity.text)
        setHintTextColor(muted)
        setPadding(dp(12), dp(8), dp(12), dp(8))
         background = gradientSurface(raised, 10)
         setSingleLine(!multiline)
        if (multiline) {
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        setOnFocusChangeListener { view, hasFocus ->
            if (hasFocus) {
                view.post { contentScroll?.let { ensureFocusedEditorVisible(it) } }
                view.postDelayed({ contentScroll?.let { ensureFocusedEditorVisible(it) } }, 250L)
            }
        }
    }

    private fun switchRow(labelValue: String, description: String, checked: Boolean, changed: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val copy = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(this@MainActivity).apply { text = labelValue; textSize = 14f; setTextColor(this@MainActivity.text) }
        copy.addView(name)
        val detail = TextView(this@MainActivity).apply { text = description; textSize = 11f; setTextColor(muted) }
        copy.addView(detail)
        row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            isChecked = checked
            thumbTintList = ColorStateList.valueOf(if (checked) Color.WHITE else Color.rgb(205, 215, 239))
            trackTintList = ColorStateList.valueOf(if (checked) Color.rgb(104, 72, 210) else Color.rgb(42, 53, 92))
            setOnCheckedChangeListener { _, value ->
                thumbTintList = ColorStateList.valueOf(if (value) Color.WHITE else Color.rgb(205, 215, 239))
                trackTintList = ColorStateList.valueOf(if (value) Color.rgb(104, 72, 210) else Color.rgb(42, 53, 92))
                changed(value)
            }
        }
        row.addView(toggle)
        targetContainer().addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(2)) })
    }

    private fun controlRow(left: View, middle: View, right: View): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(left, LinearLayout.LayoutParams(dp(54), dp(46)))
        addView(middle, LinearLayout.LayoutParams(0, dp(46), 1f))
        addView(right, LinearLayout.LayoutParams(dp(54), dp(46)))
    }

    private fun seekPreference(name: String, initial: Int, min: Int, max: Int, changed: (Int) -> Unit) {
        val value = TextView(this).apply { text = "$initial%"; textSize = 12f; setTextColor(accent) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val labelView = TextView(this@MainActivity).apply { text = name; textSize = 13f; setTextColor(this@MainActivity.text) }
        row.addView(labelView, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(value)
        targetContainer().addView(row, LinearLayout.LayoutParams(-1, dp(32)).apply { setMargins(0, dp(5), 0, 0) })
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(Color.rgb(194, 137, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val current = min + progress
                    value.text = "$current%"
                    changed(current)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        targetContainer().addView(seek, LinearLayout.LayoutParams(-1, dp(42)))
    }

    private fun progress(name: String, amount: Float) {
        val labelView = TextView(this).apply { text = name; textSize = 12f; setTextColor(muted) }
        targetContainer().addView(labelView, LinearLayout.LayoutParams(-1, dp(25)).apply { setMargins(0, dp(6), 0, 0) })
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.TRANSPARENT)
            clipChildren = false
        }
        val fill = View(this).apply { background = rounded(accent, 4, null) }
        val rest = Space(this)
        bar.addView(fill, LinearLayout.LayoutParams(0, dp(6), amount.coerceIn(0f, 1f)))
        bar.addView(rest, LinearLayout.LayoutParams(0, dp(6), (1f - amount).coerceIn(0f, 1f)))
        bar.background = rounded(raised, 4, border)
        targetContainer().addView(bar, LinearLayout.LayoutParams(-1, dp(7)))
    }

    private fun targetContainer() = activeCard ?: content

    private fun imeEnabled(): Boolean {
        return runCatching {
            val manager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            manager.enabledInputMethodList.any { it.packageName == packageName }
        }.getOrDefault(false)
    }

    private fun defaultIme(): Boolean {
        return runCatching {
            Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.startsWith("$packageName/") == true
        }.getOrDefault(false)
    }

    private fun accessibilityEnabled(): Boolean {
        return runCatching {
            Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.contains(packageName) == true
        }.getOrDefault(false)
    }

    private fun sendAutoCommand(action: String) {
        sendBroadcast(Intent(action).setPackage(packageName))
        Toast.makeText(this, "Auto-Type command sent", Toast.LENGTH_SHORT).show()
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int?): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            stroke?.let { setStroke(dp(1), it) }
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()

    private val blue get() = if (dark) Color.rgb(65, 128, 255) else Color.rgb(78, 91, 214)

    private fun gradientButton(start: Int, end: Int, radius: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(150, 122, 145, 255))
        }

    private fun gradientOutline(radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), if (dark) Color.rgb(62, 116, 255) else Color.rgb(88, 88, 194))
        }

    private fun gradientSurface(fill: Int, radius: Int): GradientDrawable {
        val end = when {
            fill == iceWash -> if (dark) Color.rgb(8, 29, 73) else Color.rgb(230, 235, 255)
            fill == goldWash -> if (dark) Color.rgb(35, 19, 64) else Color.rgb(244, 237, 255)
            fill == raised -> if (dark) Color.rgb(16, 25, 53) else Color.rgb(244, 242, 255)
            else -> if (dark) Color.rgb(9, 25, 51) else Color.rgb(245, 243, 255)
        }
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(fill, end),
        ).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), if (dark) Color.rgb(41, 92, 220) else border)
        }
    }
}